﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace connection
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {



        }

       

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "")
            {
                String s = "select * from login where username='" + textBox1.Text + "' and password='" + textBox2.Text + "'";
                SqlDataAdapter d = new SqlDataAdapter(s, Class1.c);
                DataTable t = new DataTable();
                d.Fill(t);
                if (t.Rows.Count > 0)
                {
                    home a = new home();
                    a.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Please Check Your Username And Password..");
                }
            }
            else
            {
                MessageBox.Show("Please Enter Values...");
            }
          
        }

      

      

        private void button2_Click(object sender, EventArgs e)
        {
            clear();
        }
        private void clear()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox1.Focus();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            registration r = new registration();
            r.Show();
            this.Hide();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }

    
}
