﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace create_bill
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            clear();
        }

        private void clear()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox1.Focus();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            clear();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string s = "select * from details where meterno='"+textBox2.Text+"'";
            SqlDataAdapter d = new SqlDataAdapter(s, Class1.c);
            DataTable dt = new DataTable();
            int a = d.Fill(dt);

            if (a > 0)
            {
                MessageBox.Show("A Meter Number Axists..");
            }
            else
            {
                if (textBox1.Text != "" && textBox2.Text != "")
                {
                    string i = " insert into details values('" + textBox1.Text + "','" + textBox2.Text + "')";
                    SqlDataAdapter d1 = new SqlDataAdapter(i, Class1.c);
                    DataTable dt1 = new DataTable();
                    int a1 = d1.Fill(dt1);

                    if (a1 == 0)
                    {
                        MessageBox.Show("Customer Inserted..", "database", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        clear();

                        Form2 f = new Form2();
                        f.Show();
                        this.Hide();

                    }
                    else
                    {
                        MessageBox.Show("Customer Not Inserted..", "database", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        clear();
                    }
                }
                else
                {
                    MessageBox.Show("Please Enter Details");
                }
            }

            }

        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                Form1 f = new Form1();
                f.Show();
                this.Hide();
                
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
