﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace create_bill
{
    public partial class Form3 : Form
    {
        int pre_uni, curr_uni,tot_unit, tot;
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            string s = "select * from details";
            SqlDataAdapter d = new SqlDataAdapter(s, Class1.c);
            DataTable dt = new DataTable();
            d.Fill(dt);

            comboBox1.DataSource = dt;
            comboBox1.DisplayMember = "meterno";


        }
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                Form1 f = new Form1();
                f.Show();
                this.Hide();

            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string i = " insert into bill_done values('"+comboBox1.Text+"','" + textBox1.Text + "','" + textBox2.Text + "','"+comboBox2.Text+"','"+textBox3.Text+"')";
            SqlDataAdapter d = new SqlDataAdapter(i, Class1.c);
            DataTable dt = new DataTable();
            d.Fill(dt);

            Form4 form = new Form4();
            form.Show();
            this.Hide();
        }

        private void Form3_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_TextChanged(object sender, EventArgs e)
        {
            string s = "select * from bill_done where meterno='"+comboBox1.Text+"'";
            SqlDataAdapter d = new SqlDataAdapter(s, Class1.c);
            DataTable dt = new DataTable();
            d.Fill(dt);

            if(dt.Rows.Count > 0)
            {
               for(int i = 0; i < dt.Rows.Count; i++)   
                {
                    textBox1.Text = dt.Rows[i]["curr_uni"].ToString();
                  
                }
            }
            else
            {
                textBox1.Text = "0";
            }
        }

        

        private void button1_Click(object sender, EventArgs e)
        {
            clear();
        }
        private void clear()
        {
            comboBox1.Text = "";
            textBox1.Text = "";
            textBox2.Text = "";
            comboBox2.Text = "";
            textBox3.Text = "";


        }

        

        private void comboBox2_TextChanged(object sender, EventArgs e)
        {
            string s = "select * from bill_done where meterno='" + comboBox1.Text + "' and month='" + comboBox2.Text + "'";
            SqlDataAdapter d = new SqlDataAdapter(s, Class1.c);
            DataTable dt = new DataTable();
            int a = d.Fill(dt);

            if (a > 0)
            {
                MessageBox.Show("Already Bill Exist..");
            }
            else
            {
                pre_uni = Convert.ToInt32(textBox1.Text);
                curr_uni = Convert.ToInt32(textBox2.Text);
                tot_unit = curr_uni - pre_uni;

                if (tot_unit < 100)
                {
                    tot = tot_unit * 6;
                    Console.WriteLine("Your due bill costs : " + tot);
                }
                else if (100 <= tot_unit && tot_unit <= 200)
                {
                    tot = tot_unit * 7;
                    Console.WriteLine("Your due bill costs : " + tot);
                }
                else if (200 <= tot_unit && tot_unit <= 300)
                {
                    tot = tot_unit * 8;
                    Console.WriteLine("Your due bill costs : " + tot);
                }
                else if (300 <= tot_unit && tot_unit <= 400)
                {
                    tot = tot_unit * 9;
                    Console.WriteLine("Your due bill costs : " + tot);
                }
                else
                {
                    tot = tot_unit * 10;
                    Console.WriteLine("Your due bill costs : " + tot);
                }

                textBox3.Text=tot.ToString();
            }


        }
    }
}
