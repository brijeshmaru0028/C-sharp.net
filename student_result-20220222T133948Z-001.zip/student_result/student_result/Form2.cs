﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace student_result
{
    public partial class Form2 : Form
    {
        int total, per;
        string result, grade;
        public Form2()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void show()
        {
            string s = "select * from student";
            SqlDataAdapter d = new SqlDataAdapter(s, Class1.c);
            DataTable dt = new DataTable();
            d.Fill(dt);
            dataGridView1.DataSource = dt;
            
        }

        private void Form2_Load(object sender, EventArgs e)
        {

            show();
            
           
        }

        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            clear();
        }

        private void clear()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox1.Focus();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow r = dataGridView1.Rows[e.RowIndex];

            textBox1.Text=(r.Cells[0].Value.ToString());
            
        }

        private void button1_Click(object sender, EventArgs e)
        {

            total = Convert.ToInt32(textBox2.Text) + Convert.ToInt32(textBox3.Text) + Convert.ToInt32(textBox4.Text) + Convert.ToInt32(textBox5.Text);
            per = total / 4;

            if (Convert.ToInt32(textBox2.Text) > 40 || Convert.ToInt32(textBox3.Text) > 40 || Convert.ToInt32(textBox4.Text) > 40 || Convert.ToInt32(textBox5.Text) > 40)
            {
                result = "PASS";
            }
            else
            {
                result = "FAIL";
            }

            if (per >= 90)
            {
                grade = "O GRADE";
            }
            else if (per >= 80)
            {
                grade = "A GRADE";
            }
            else if (per >= 70)
            {
                grade = "B GRADE";
            }
            else if (per >= 60)
            {
                grade = "C GRADE";
            }
            else if (per >= 50)
            {
                grade = "D GRADE";
            }
            else
            {
                grade = "E GRADE";
            }

         string i = "insert into result values('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "','" + textBox5.Text + "','" + total + "','" + per + "','" + result + "','" + grade + "')";
         SqlDataAdapter d = new SqlDataAdapter(i, Class1.c);
         DataTable dt = new DataTable();
         int a = d.Fill(dt);

                if (a == 0)
                {
                    MessageBox.Show("Inserted..", "database", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    clear();

                    Form3 f = new Form3();
                    f.Show();
                    this.Hide();

  

                }
                else
                {
                    MessageBox.Show("Not Inserted..", "database", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    clear();
                }
           

        }
    }
}
