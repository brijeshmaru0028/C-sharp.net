﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace student_result
{
    class Class1
    {
        public static SqlConnection c = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\student_result.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True");
    }
}
