﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace form
{
    public partial class Form1 : Form
    {
        int i = 0, c = 30;
        public Form1()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            i++;
            if (i == 1)
            {
                ovalShape1.Visible = false;
                ovalShape2.Visible = true;
                ovalShape3.Visible = false;
                ovalShape4.Visible = true;
                ovalShape5.Visible = false;
                ovalShape6.Visible = false;
                ovalShape7.Visible = true;
                ovalShape8.Visible = false;
                ovalShape9.Visible = false;
                timer1.Interval = 10000;
            }
            else if (i == 2)
            {
                ovalShape1.Visible = true;
                ovalShape2.Visible = false;
                ovalShape3.Visible = false;
                ovalShape4.Visible = false;
                ovalShape5.Visible = false;
                ovalShape6.Visible = true;
                ovalShape7.Visible = true;
                ovalShape8.Visible = false;
                ovalShape9.Visible = false;

            }
            else
            {
                ovalShape1.Visible = true;
                ovalShape2.Visible = false;
                ovalShape3.Visible = false;
                ovalShape4.Visible = true;
                ovalShape6.Visible = false;
                ovalShape5.Visible = false;
                ovalShape7.Visible = false;
                ovalShape8.Visible = false;
                ovalShape9.Visible = true;

                i = 0;
            }

        }


        private void timer2_Tick(object sender, EventArgs e)
        {
            if (c >= 20)
            {
                label1.Text = c.ToString();
                c--;
                if (c == 23)
                {
                    ovalShape5.Visible = true;
                }
                else if (c == 21)
                {
                    ovalShape3.Visible = true;
                }
            }
            else if (c >= 10)
            {
                label1.Text = "";
                label2.Text = c.ToString();
                c--;
                if (c == 13)
                {
                    ovalShape8.Visible = true;
                }
                else if (c == 11)
                {
                    ovalShape5.Visible = true;
                }
               
            }
            else if (c >= 0)
            {
                label1.Text = "";
                label2.Text = "";
                label3.Text = c.ToString();
                c--;
                if (c == 3)
                {
                    ovalShape3.Visible = true;
                }
                else if (c == 1)
                {
                    ovalShape8.Visible = true;
                }
            }
            else
            {
                c = 30;
                timer2.Enabled = false;
                timer1.Enabled = false;
            }
        }
       

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                Application.Exit();   
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

    }
}
