﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace array_sum_multi
{
    class Program
    {
        class A
        {
           public int a, b, s = 0, m = 1;
        }
        class B : A
        {
            public void get()
            {
                Console.Write("Enter Value For a [row] :");
                a = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Value For b [column] :");
                b = Convert.ToInt32(Console.ReadLine());
            }
        }
        class C : B
        {
            public void disp()
            {
                int[,] aa = new int[a, b];

                for (int i = 0; i < a; i++)
                {
                    for (int j = 0; j < b; j++)
                    {
                        Console.Write("Enter Value For Array:");
                        aa[i, j] = Convert.ToInt32(Console.ReadLine());

                        if (aa[i, j] % 2 == 0)
                        {
                            s += aa[i, j];

                        }
                        else
                        {
                            m *= aa[i, j];
                        }
                    }
                }
                Console.WriteLine("Sum Of Even No :" + s);
                Console.WriteLine("Multiplication Of Odd No :" + m);
            }
        }
        
        static void Main(string[] args)
        {
            C c1 = new C();
            c1.get();
            c1.disp();
           
            Console.Read();
        }
    }
}
