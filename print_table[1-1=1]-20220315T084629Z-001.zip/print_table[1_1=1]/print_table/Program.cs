﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace print_table
{
    class Program
    {
        class A
        {
            public int n, i, j;
        }
        class B : A
        {
            public void get()
            {
                Console.WriteLine("Enter Value n:");
                n = Convert.ToInt32(Console.ReadLine());
            }
        }
        class C : B
        {
            public void disp()
            {
                for (i = 1; i <= n; i++)
                {
                    for (j = 1; j <= 10; j++)
                    { 
                        Console.WriteLine(i + " * " + j + " = " + i * j);
                    }
                    Console.WriteLine();
                }
            }

        }
        static void Main(string[] args)
        {
            C a = new C();
            a.get();
            a.disp();

            Console.Read();
        }
    }
}
