﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace attendance_student
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            string s = "select * from stud";
            SqlDataAdapter d = new SqlDataAdapter(s, Class1.c);
            DataTable dt = new DataTable();
            d.Fill(dt);

            comboBox1.DataSource = dt;
            comboBox1.DisplayMember = "rollno";

            dateTimePicker1.Value = System.DateTime.Now;
            

        }
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                this.Hide();
                Form1 f = new Form1();
                f.Show();

            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            clear();       
        }

        private void clear()
        {
            comboBox1.Text = "";
            comboBox2.Text = "";
            comboBox1.Focus();
        }

        private void comboBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string s = "select * from atten where rollno='"+comboBox1.Text+"' and date='"+dateTimePicker1.Text+"'";
            SqlDataAdapter d = new SqlDataAdapter(s, Class1.c);
            DataTable dt = new DataTable();
            int a = d.Fill(dt);

            if(a > 0)
            {
                Form3 f = new Form3();
                f.Show();
                this.Hide();

            }
            else
            {
                    string i = " insert into atten values('" + comboBox1.Text + "','" + dateTimePicker1.Text + "','" + comboBox2.Text + "')";
                    SqlDataAdapter d1 = new SqlDataAdapter(i, Class1.c);
                    DataTable dt1 = new DataTable();
                    int a1 = d1.Fill(dt1);

                    if (a1 == 0)
                    {
                       MessageBox.Show("Attendance Fillup","database",MessageBoxButtons.OK,MessageBoxIcon.Information); 
                       clear();
                    }
                    else
                    {
                        MessageBox.Show("Attendance Not Fillup", "database", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        clear();
                    }
                
            }
            
        }
    }
}
